#!/usr/bin/env bash
# cpu-flags-info.sh
# Lê as flags da CPU e explica o que cada uma significa.
# Uso:
#   ./cpu-flags-info.sh            # tabela normal
#   ./cpu-flags-info.sh --markdown # tabela em Markdown

set -euo pipefail

MARKDOWN=0
if [[ "${1-}" == "--markdown" ]]; then
  MARKDOWN=1
fi

# Obtém arquitetura e flags de forma robusta
ARCH="$(lscpu | awk -F: '/Architecture|Arquitetura/{gsub(/^[ \t]+/, "", $2); print $2; exit}')"
if [[ -z "${ARCH}" ]]; then
  ARCH="$(uname -m || true)"
fi

FLAGS_LINE="$(grep -m1 -i -E '^flags[[:space:]]*:' /proc/cpuinfo | sed -E 's/^flags[[:space:]]*:[[:space:]]*//I' || true)"
if [[ -z "${FLAGS_LINE}" ]]; then
  # fallback (algumas distros listam em lscpu)
  FLAGS_LINE="$(lscpu | awk -F: '/Flags|Bandeiras/{gsub(/^[ \t]+/, "", $2); print $2; exit}')"
fi

if [[ -z "${FLAGS_LINE}" ]]; then
  echo "Não foi possível detectar as flags de CPU neste sistema."
  exit 1
fi

# Constrói o dicionário de descrições
declare -A DESC

# Básicas / execução
DESC[fpu]="Unidade de ponto flutuante presente"
DESC[tsc]="Time Stamp Counter (contador de ciclos)"
DESC[rdtscp]="Leitura serializada do TSC (RDTSCP)"
DESC[clflush]="Limpeza de linhas de cache (CLFLUSH)"
DESC[cx16]="CMPXCHG16B (sincronização 128 bits)"
DESC[lahf_lm]="LAHF/SAHF disponível em modo 64 bits"
DESC[nx]="Bit NX (No-eXecute) – proteção contra execução indevida"
DESC[pae]="Physical Address Extension (endereçamento >4GB em x86 32 bits)"
DESC[ht]="Hyper‑Threading (múltiplas threads por núcleo)"
DESC[ssbd]="Mitigação de Speculative Store Bypass"
DESC[ibrs]="Mitigação para Spectre v2 (IBRS)"
DESC[ibpb]="Barreira entre processos (IBPB) – Spectre v2"
DESC[stibp]="Barreira entre threads (STIBP) – Spectre v2"
DESC[mds]="Mitigações para Microarchitectural Data Sampling"
DESC[pcid]="Process‑context identifiers (melhora TLB com ASIDs)"
DESC[invpcid]="Invalidar TLB seletivamente (INVPCID)"

# SIMD / vetoriais
DESC[mmx]="MMX – instruções multimídia"
DESC[sse]="SSE – SIMD 128 bits (geração 1)"
DESC[sse2]="SSE2 – SIMD 128 bits (dobras e ponto flutuante)"
DESC[sse3]="SSE3 – extensões SSE"
DESC[ssse3]="SSSE3 – extensões suplementares SSE3"
DESC[sse4_1]="SSE4.1 – operações vetoriais adicionais"
DESC[sse4_2]="SSE4.2 – CRC32 e outras instruções"
DESC[popcnt]="POPcnt – contagem de bits ativos"
DESC[avx]="AVX – vetores 256 bits"
DESC[avx2]="AVX2 – inteiros 256 bits, gather, etc."
DESC[fma]="FMA3 – Fused Multiply‑Add"
DESC[fma4]="FMA4 – Fused Multiply‑Add (AMD, legado)"
DESC[bmi1]="BMI1 – Bit Manipulation Instructions 1"
DESC[bmi2]="BMI2 – Bit Manipulation Instructions 2"
DESC[aes]="AES‑NI – criptografia AES por hardware"
DESC[sha_ni]="SHA – aceleração SHA por hardware (Intel/ARMv8)"
DESC[sha]="SHA – aceleração SHA por hardware"
DESC[pclmulqdq]="Carry‑less multiply – usado em criptografia/GCM"

# Aleatoriedade/segurança
DESC[rdrand]="Gerador de números aleatórios por hardware (RDRAND)"
DESC[rdseed]="Gerador de sementes aleatórias seguras (RDSEED)"
DESC[smep]="Supervisor Mode Execution Protection"
DESC[smap]="Supervisor Mode Access Prevention"
DESC[umip]="User‑Mode Instruction Prevention"

# Virtualização
DESC[vmx]="VT‑x (virtualização por hardware – Intel)"
DESC[svm]="AMD‑V (virtualização por hardware – AMD)"
DESC[ept]="Extended Page Tables (Intel VT‑x)"
DESC[npt]="Nested Page Tables (AMD‑V)"

# Antigas/legado
DESC[3dnow]="3DNow! (AMD – legado)"
DESC[3dnowext]="3DNow! Ext (AMD – legado)"
DESC[abm]="Advanced Bit Manipulation (AMD: LZCNT/POPCNT)"

# Arm (se aplicável, algumas aparecem em ARM64 com nomes diferentes)
DESC[asimd]="ARM NEON/ASIMD – SIMD"
DESC[crc32]="CRC32 por hardware (ARM)"
DESC[aes]="AES por hardware (ARM/Intel)"
DESC[pmull]="Polynomial Multiply (ARM, GCM)"
DESC[atomics]="Instruções atômicas (ARMv8.1+)"

# Formatação de saída
if [[ ${MARKDOWN} -eq 1 ]]; then
  echo "| Campo | Valor |"
  echo "|---|---|"
  echo "| Arquitetura | ${ARCH} |"
  # Virtualização detectada
  if grep -qw vmx <<<"${FLAGS_LINE}"; then VIRT="Intel VT‑x (vmx)"; fi
  if grep -qw svm <<<"${FLAGS_LINE}"; then VIRT="${VIRT:-}$( [[ -n "${VIRT-}" ]] && echo "; " )AMD‑V (svm)"; fi
  echo "| Virtualização | ${VIRT:-Não detectado} |"
  echo
  echo "| Flag | Descrição |"
  echo "|---|---|"
else
  printf "Arquitetura: %s\n" "${ARCH}"
  if grep -qw vmx <<<"${FLAGS_LINE}"; then VTX="Intel VT‑x (vmx)"; fi
  if grep -qw svm <<<"${FLAGS_LINE}"; then AMDV="AMD‑V (svm)"; fi
  printf "Virtualização: %s\n\n" "${VTX-}${VTX:+  }${AMDV-:Não detectado}"
  printf "%-18s  %s\n" "Flag" "Descrição"
  printf "%-18s  %s\n" "------------------" "---------------------------------------------"
fi

# Ordena flags alfabeticamente para exibir
# (quebra em linhas, normaliza espaços, ordena único)
mapfile -t ALL_FLAGS < <(tr ' ' '\n' <<<"${FLAGS_LINE}" | sed '/^$/d' | sort -u)

for f in "${ALL_FLAGS[@]}"; do
  desc="${DESC[$f]:-—}"
  if [[ ${MARKDOWN} -eq 1 ]]; then
    echo "| ${f} | ${desc} |"
  else
    printf "%-18s  %s\n" "${f}" "${desc}"
  fi
done

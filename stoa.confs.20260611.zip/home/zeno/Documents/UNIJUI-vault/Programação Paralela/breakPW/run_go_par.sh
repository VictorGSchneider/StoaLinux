#!/usr/bin/env bash
set -euo pipefail
PASS="${1:-99999999}"
NWORKERS="${2:-$(nproc)}"
OUT="${3:-times_go_par_${NWORKERS}w.csv}"
echo "run,workers,seconds" > "$OUT"
for i in $(seq 1 20); do
  SEC=$( ./bin/go_par "$PASS" "$NWORKERS" | awk '/ELAPSED_SEC/{print $2}' )
  echo "$i,$NWORKERS,$SEC" >> "$OUT"
  echo "run $i (w=$NWORKERS) => $SEC s"
done

#!/usr/bin/env bash
set -euo pipefail

# Padrão: somente GPL v3
ID="GPL-3.0-only"
OWNER=""   # opcional: seu nome/equipe, ex.: "2025 Fulano e Equipe"

# Uso: ./spdxify.sh [--or-later] [--owner "Seu Nome/Equipe"]
while [[ $# -gt 0 ]]; do
  case "$1" in
    --or-later) ID="GPL-3.0-or-later"; shift ;;
    --owner) OWNER="${2:-}"; shift 2 ;;
    *) echo "Uso: $0 [--or-later] [--owner \"Seu Nome/Equipe\"]" ; exit 1 ;;
  endesac
done

echo "SPDX a aplicar: $ID"
[[ -n "$OWNER" ]] && echo "Owner: $OWNER"

# Função que insere header se NÃO existir ainda
insert_header() {
  local file="$1" lang="$2"
  # já tem SPDX?
  if grep -q 'SPDX-License-Identifier:' "$file"; then
    echo "→ já tem SPDX: $file"
    return 0
  fi

  # monta cabeçalho por linguagem
  local header=""
  if [[ "$lang" == "go" ]]; then
    header="// SPDX-License-Identifier: ${ID}"
    [[ -n "$OWNER" ]] && header+=$'\n'"// Copyright (c) ${OWNER}"
  else
    header="/* SPDX-License-Identifier: ${ID} */"
    [[ -n "$OWNER" ]] && header+=$'\n'"/* Copyright (c) ${OWNER} */"
  fi

  # cria arquivo temporário e injeta
  local tmp
  tmp="$(mktemp)"
  {
    printf '%s\n\n' "$header"
    cat "$file"
  } > "$tmp"
  mv "$tmp" "$file"
  echo "✓ SPDX inserido: $file"
}

# Percorre arquivos .c .h .go (ignora bin/, .git/, vendor/)
while IFS= read -r -d '' f; do
  case "$f" in
    *.go) insert_header "$f" "go" ;;
    *.c|*.h) insert_header "$f" "c" ;;
  esac
done < <(find . -type f \( -name '*.c' -o -name '*.h' -o -name '*.go' \) \
          -not -path './.git/*' -not -path './bin/*' -not -path './vendor/*' -print0)

echo "Concluído."


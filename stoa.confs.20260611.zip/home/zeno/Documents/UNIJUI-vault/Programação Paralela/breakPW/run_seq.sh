#!/usr/bin/env bash
set -euo pipefail
PASS="${1:-99999999}"
OUT="${2:-times_seq.csv}"
echo "run,seconds" > "$OUT"
for i in $(seq 1 20); do
  SEC=$( ./bin/seq "$PASS" | awk '/ELAPSED_SEC/{print $2}' )
  echo "$i,$SEC" >> "$OUT"
  echo "run $i => $SEC s"
done

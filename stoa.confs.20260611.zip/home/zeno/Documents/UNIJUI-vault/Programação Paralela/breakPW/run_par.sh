#!/usr/bin/env bash
set -euo pipefail
PASS="${1:-99999999}"
NTHREADS="${2:-$(nproc)}"
OUT="${3:-times_par_${NTHREADS}t.csv}"
echo "run,threads,seconds" > "$OUT"
for i in $(seq 1 20); do
  SEC=$( ./bin/par "$PASS" "$NTHREADS" | awk '/ELAPSED_SEC/{print $2}' )
  echo "$i,$NTHREADS,$SEC" >> "$OUT"
  echo "run $i (t=$NTHREADS) => $SEC s"
done

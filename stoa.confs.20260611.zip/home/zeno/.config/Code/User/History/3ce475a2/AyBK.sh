#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║  STOA LINUX — Memento Mori Toggle                           ║
# ║  "Remember that you will die." — Stoic tradition             ║
# ╚══════════════════════════════════════════════════════════════╝

WIDGET="memento"

# `eww active-windows` is not a real subcommand; `eww windows` marks
# active windows with a leading `*`.
eww list-windows 2>/dev/null | grep -q "^${WIDGET}$"

if [ $? -eq 0 ]; then
    echo "Encontrou — fechando"
    eww close "$WIDGET"
else
    echo "Não encontrou — abrindo"
    eww open "$WIDGET"
fi
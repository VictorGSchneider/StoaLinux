cd ~/StoaLinux
git fetch origin
git checkout main
git reset --hard origin/main

# Script de reescrita (case por SHA prefix)
cat > /tmp/msg-filter.sh <<'EOSCRIPT'
#!/bin/bash
sha="$GIT_COMMIT"
case "$sha" in
  d2edc48*) echo 'chore(archinstall): set kb_layout=br-abnt2; raise parallel downloads 5->10; drop libinput-gestures' ;;
  b04b5ed*) echo 'chore: scaffold .github/dependabot.yml (template; ecosystems/typo fixed next)' ;;
  3a823ae*) echo 'fix(dependabot): replace placeholder ecosystems list; fix "diary" -> "daily" typo' ;;
  9b6db9b*) echo 'chore(env/theme): switch FILE_MANAGER to thunar; enable NVIDIA Wayland envs; refresh qt5ct/qt6ct/rofi/hypr' ;;
  63ebe73*) echo 'chore: extend .gitignore.txt with build/cache/egg-info entries' ;;
  abcb942*) echo 'chore: include dfm.egg-info (reverted in next commit)' ;;
  5ac0c6c*) echo 'chore: rename .gitignore.txt to .gitignore' ;;
  2e0cf69*) echo 'fix(gpu-setup): scope NVIDIA detection to VGA/3D/Display devices' ;;
  9e49477*) echo 'feat(hypr): add hyprland.ooo variant; add capture/memento debug logs' ;;
  99d458e*) echo 'chore(hypr): rebind launcher to Super+Space, settings to Super+S; autostart numlockx' ;;
  448044d*) echo 'restore(stoa-store): replace placeholder with full 2611-line script' ;;
  ce59180*) echo 'fix(stoa-capture): use "$*" instead of "$@" in debug echo' ;;
  8df1dff*) echo 'fix(stoa-capture): use "$*" in case-branch debug echo; add trailing newline' ;;
  4297184*) echo 'feat(post-install): offer DAMX install when running on Acer hardware' ;;
  *)        cat ;;   # mantém mensagem original
esac
EOSCRIPT
chmod +x /tmp/msg-filter.sh

# Reescreve só mensagens, do range 162d219..HEAD
FILTER_BRANCH_SQUELCH_WARNING=1 git filter-branch -f \
  --msg-filter /tmp/msg-filter.sh \
  162d219..HEAD

# Confere
git log 162d219..HEAD --oneline | head -25

# Push
git push --force-with-lease origin main
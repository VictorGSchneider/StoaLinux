#!/bin/bash
set -e
cd ~/StoaLinux

echo "==> Sincronizando main"
git fetch origin
git checkout main
git reset --hard origin/main

echo "==> Gerando reword script"
cat > /tmp/seq-edit.sh <<'EOSCRIPT'
#!/bin/bash
python3 - "$1" <<'PY'
import sys
todo_path = sys.argv[1]
renames = {
    'd2edc48': 'chore(archinstall): set kb_layout=br-abnt2; raise parallel downloads 5->10; drop libinput-gestures',
    'b04b5ed': 'chore: scaffold .github/dependabot.yml (template; ecosystems/typo fixed next)',
    '3a823ae': 'fix(dependabot): replace placeholder ecosystems list; fix "diary" -> "daily" typo',
    '9b6db9b': 'chore(env/theme): switch FILE_MANAGER to thunar; enable NVIDIA Wayland envs; refresh qt5ct/qt6ct/rofi/hypr',
    '63ebe73': 'chore: extend .gitignore.txt with build/cache/egg-info entries',
    'abcb942': 'chore: include dfm.egg-info (reverted in next commit)',
    '5ac0c6c': 'chore: rename .gitignore.txt to .gitignore',
    '2e0cf69': 'fix(gpu-setup): scope NVIDIA detection to VGA/3D/Display devices',
    '9e49477': 'feat(hypr): add hyprland.ooo variant; add capture/memento debug logs',
    '99d458e': 'chore(hypr): rebind launcher to Super+Space, settings to Super+S; autostart numlockx',
    '448044d': 'restore(stoa-store): replace placeholder with full 2611-line script',
    'ce59180': 'fix(stoa-capture): use "$*" instead of "$@" in debug echo',
    '8df1dff': 'fix(stoa-capture): use "$*" in case-branch debug echo; add trailing newline',
    '4297184': 'feat(post-install): offer DAMX install when running on Acer hardware',
}
with open(todo_path) as f:
    lines = f.readlines()
out = []
for line in lines:
    out.append(line)
    parts = line.split()
    if len(parts) >= 2 and parts[0] == 'pick':
        for k, v in renames.items():
            if parts[1].startswith(k):
                out.append("exec git commit --amend -m '%s'\n" % v.replace("'", "'\\''"))
                break
with open(todo_path, 'w') as f:
    f.writelines(out)
PY
EOSCRIPT
chmod +x /tmp/seq-edit.sh

echo "==> Range:"
git log 162d219..HEAD --oneline | wc -l
echo "commits a passar pelo rebase"

echo "==> Rebasing"
GIT_SEQUENCE_EDITOR=/tmp/seq-edit.sh git rebase -i 162d219

echo "==> Novo log:"
git log 162d219..HEAD --oneline | head -25

echo "==> Push"
git push --force-with-lease origin main

echo "==> Pronto. Reabilite proteção de main em Settings → Branches."
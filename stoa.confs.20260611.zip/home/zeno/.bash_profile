#
# ~/.bash_profile
#

[[ -f ~/.bashrc ]] && . ~/.bashrc

# StoaLinux: autostart Hyprland on tty1
[ -f "/home/zeno/StoaLinux/shell/stoa-autostart-hyprland.sh" ] && . "/home/zeno/StoaLinux/shell/stoa-autostart-hyprland.sh"
